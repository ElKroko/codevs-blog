const fallbackData = {
  pageInfo: {
    "bienvenido-a-codevs": {
      title: "Bienvenido a CODEVS",
      content: `
        <p>🚀 <strong>Bienvenido a la Comunidad CODEVS</strong></p>
        <p>Somos una comunidad apasionada de desarrolladores dedicada a impulsar el crecimiento profesional y personal de nuestros miembros a través del intercambio de conocimientos, experiencias y oportunidades.</p>
        
        <h3>💡 ¿Qué encontrarás aquí?</h3>
        <ul>
          <li><strong>Tutoriales y Guías:</strong> Contenido técnico de alta calidad sobre las últimas tecnologías</li>
          <li><strong>Proyectos Colaborativos:</strong> Oportunidades para trabajar en equipo y construir tu portafolio</li>
          <li><strong>Networking:</strong> Conecta con otros desarrolladores y expande tu red profesional</li>
          <li><strong>Eventos y Workshops:</strong> Sesiones de aprendizaje en vivo y talleres prácticos</li>
        </ul>
        
        <p><em>Nota: Actualmente mostrando contenido de fallback mientras solucionamos problemas de conectividad.</em></p>
      `
    }
  },
  posts: [
    {
      title: "Introducción a React Hooks: Una Guía Completa",
      excerpt: "Descubre cómo los React Hooks han revolucionado el desarrollo de componentes funcionales y aprende a implementarlos en tus proyectos.",
      content: "<p>Los React Hooks son una característica fundamental del desarrollo moderno con React...</p>",
      date: "2025-05-28T10:00:00",
      slug: "introduccion-react-hooks-guia-completa",
      featuredImage: "/blog-placeholder-1.jpg"
    },
    {
      title: "Docker para Desarrolladores: Containerización Simplificada",
      excerpt: "Aprende los fundamentos de Docker y cómo puede revolucionar tu flujo de trabajo de desarrollo y despliegue.",
      content: "<p>Docker ha transformado la manera en que desarrollamos y desplegamos aplicaciones...</p>",
      date: "2025-05-27T15:30:00",
      slug: "docker-desarrolladores-containerizacion",
      featuredImage: "/blog-placeholder-2.jpg"
    },
    {
      title: "Node.js y Express: Construyendo APIs REST Modernas",
      excerpt: "Domina la creación de APIs robustas y escalables utilizando Node.js y Express framework con las mejores prácticas.",
      content: "<p>Node.js y Express forman una combinación poderosa para el desarrollo backend...</p>",
      date: "2025-05-26T09:15:00",
      slug: "nodejs-express-apis-rest-modernas",
      featuredImage: "/blog-placeholder-3.jpg"
    }
  ]
};

const domain = "https://cms.kroko.cl";
const apiUrl = `${domain}/wp-json/wp/v2`;
const getPageInfo = async (slug) => {
  try {
    console.log(`Fetching page info for slug: ${slug} from ${apiUrl}`);
    const res = await fetch(`${apiUrl}/pages?slug=${slug}`);
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}: ${res.statusText}`);
    }
    const data = await res.json();
    if (!data || data.length === 0) {
      throw new Error(`No page found with slug: ${slug}`);
    }
    const [pageData] = data;
    if (!pageData.title || !pageData.content) {
      throw new Error("Invalid page data structure");
    }
    const { title: { rendered: title }, content: { rendered: content } } = pageData;
    console.log(`✅ Successfully fetched page: ${title}`);
    return { title, content };
  } catch (error) {
    console.warn(`⚠️  WordPress unavailable, using fallback data for page: ${slug}`);
    console.error("WordPress Error:", error);
    const fallbackPage = fallbackData.pageInfo[slug];
    if (fallbackPage) {
      return fallbackPage;
    }
    return {
      title: "Bienvenido a CODEVS",
      content: "<p>🚧 Sitio en mantenimiento. Mostrando contenido de respaldo.</p>"
    };
  }
};
const getLastestPosts = async ({ perPage = 10 } = {}) => {
  try {
    console.log(`Fetching latest posts (${perPage}) from ${apiUrl}`);
    const response = await fetch(`${apiUrl}/posts?per_page=${perPage}&_embed`);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    const results = await response.json();
    if (!results.length) {
      console.log("No posts found");
      return fallbackData.posts.slice(0, perPage);
    }
    const posts = results.map((post) => {
      const {
        title: { rendered: title },
        excerpt: { rendered: excerpt },
        content: { rendered: content },
        date,
        slug
      } = post;
      return { title, content, excerpt, date, slug };
    });
    console.log(`✅ Successfully fetched ${posts.length} posts`);
    return posts;
  } catch (error) {
    console.warn(`⚠️  WordPress unavailable, using ${fallbackData.posts.length} fallback posts`);
    console.error("WordPress Error:", error);
    return fallbackData.posts.slice(0, perPage);
  }
};
const getPostBySlug = async (slug) => {
  try {
    console.log(`Fetching post by slug: ${slug} from ${apiUrl}`);
    const response = await fetch(`${apiUrl}/posts?slug=${slug}&_embed`);
    if (!response.ok) {
      console.error(`Failed to fetch post. Status: ${response.status} ${response.statusText}`);
      throw new Error(`Failed to fetch post: ${response.status} ${response.statusText}`);
    }
    const results = await response.json();
    if (!results.length) {
      console.error(`Post not found with slug: ${slug}`);
      throw new Error(`Post not found with slug: ${slug}`);
    }
    const [post] = results;
    const {
      title: { rendered: title },
      excerpt: { rendered: excerpt },
      content: { rendered: content },
      date,
      modified,
      slug: postSlug,
      featured_media,
      author,
      categories,
      tags,
      claps_count,
      _embedded
    } = post;
    let featuredImage = null;
    if (featured_media && _embedded && _embedded["wp:featuredmedia"]) {
      featuredImage = _embedded["wp:featuredmedia"][0]?.source_url;
    }
    let authorInfo = null;
    if (_embedded && _embedded.author && _embedded.author[0]) {
      const authorData = _embedded.author[0];
      authorInfo = {
        name: authorData.name,
        description: authorData.description,
        avatar: authorData.avatar_urls?.["96"] || authorData.avatar_urls?.["48"] || "",
        url: authorData.url
      };
    }
    let categoriesData = [];
    let tagsData = [];
    if (_embedded && _embedded["wp:term"]) {
      const terms = _embedded["wp:term"].flat();
      categoriesData = terms.filter((term) => term.taxonomy === "category").map((cat) => ({
        id: cat.id,
        name: cat.name,
        slug: cat.slug
      }));
      tagsData = terms.filter((term) => term.taxonomy === "post_tag").map((tag) => ({
        id: tag.id,
        name: tag.name,
        slug: tag.slug
      }));
    }
    const wordCount = content ? content.replace(/<[^>]*>/g, "").split(/\s+/).length : 0;
    const readingTime = Math.max(1, Math.ceil(wordCount / 200));
    console.log(`Successfully fetched post: ${title}`);
    return {
      title,
      content,
      excerpt,
      date,
      modified,
      slug: postSlug,
      featuredImage,
      author: authorInfo,
      categories: categoriesData,
      tags: tagsData,
      claps: claps_count || 0,
      readingTime: `${readingTime} min`,
      id: post.id
    };
  } catch (error) {
    console.error("Error in getPostBySlug:", error);
    throw error;
  }
};

export { getLastestPosts as a, getPostBySlug as b, getPageInfo as g };
