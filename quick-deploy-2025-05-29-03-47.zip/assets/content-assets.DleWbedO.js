const contentAssets = new Map();

export { contentAssets as default };
