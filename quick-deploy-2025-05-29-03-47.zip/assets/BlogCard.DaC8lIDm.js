import { d as createAstro, c as createComponent, m as maybeRenderHead, e as addAttribute, u as unescapeHTML, a as renderTemplate } from './astro/server.BG-T_3SK.js';
import 'kleur/colors';
import 'clsx';

const $$Astro = createAstro("https://codevs.kroko.cl");
const $$BlogCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$BlogCard;
  const { title, excerpt, slug, date } = Astro2.props;
  const processExcerpt = (html) => {
    let cleaned = html.replace(/<(?!\/?(p|strong|b|em|i|a|br)\b)[^>]*>/gi, "").replace(/\s+/g, " ").trim();
    if (cleaned.length > 200) {
      cleaned = cleaned.substring(0, 200);
      const lastSpace = cleaned.lastIndexOf(" ");
      if (lastSpace > 150) {
        cleaned = cleaned.substring(0, lastSpace);
      }
      cleaned += "...";
    }
    return cleaned;
  };
  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date2 = new Date(dateString);
    return date2.toLocaleDateString("es-ES", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  };
  return renderTemplate`${maybeRenderHead()}<article class="blog-card"> <div class="card-content"> <h3> <a${addAttribute(`/blog/${slug}`, "href")} class="card-title"> ${title} </a> </h3> ${date && renderTemplate`<time class="card-date"${addAttribute(date, "datetime")}> ${formatDate(date)} </time>`} <div class="card-excerpt wp-content">${unescapeHTML(processExcerpt(excerpt))}</div> <a${addAttribute(`/blog/${slug}`, "href")} class="read-more">
Leer más →
</a> </div> </article>`;
}, "F:/Codes/CODEVS/ASTRO-WEB/codevs-blog/src/components/BlogCard.astro", void 0);

export { $$BlogCard as $ };
