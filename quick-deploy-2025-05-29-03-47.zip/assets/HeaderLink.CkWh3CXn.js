import { d as createAstro, c as createComponent, m as maybeRenderHead, e as addAttribute, B as spreadAttributes, f as renderSlot, a as renderTemplate } from './astro/server.BG-T_3SK.js';
import 'clsx';

const $$Astro = createAstro("https://codevs.kroko.cl");
const $$HeaderLink = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$HeaderLink;
  const { href, class: className, ...props } = Astro2.props;
  const pathname = Astro2.url.pathname.replace("/", "");
  const subpath = pathname.match(/[^\/]+/g);
  const isActive = href === pathname || href === "/" + (subpath?.[0] || "");
  return renderTemplate`${maybeRenderHead()}<a${addAttribute(href, "href")}${addAttribute([
    "inline-block no-underline text-gray-600 dark:text-gray-300 hover:text-primary-900 dark:hover:text-white transition-colors duration-200",
    {
      "font-bold text-primary-900 dark:text-white underline decoration-accent-900 decoration-2 underline-offset-4": isActive
    },
    className
  ], "class:list")}${spreadAttributes(props)}> ${renderSlot($$result, $$slots["default"])} </a>`;
}, "F:/Codes/CODEVS/ASTRO-WEB/codevs-blog/src/components/HeaderLink.astro", void 0);

export { $$HeaderLink as $ };
