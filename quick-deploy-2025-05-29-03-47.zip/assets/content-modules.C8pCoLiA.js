const contentModules = new Map([
["src/content/blog/using-mdx.mdx", () => import('./using-mdx.B6lAE9Oi.js')]]);

export { contentModules as default };
