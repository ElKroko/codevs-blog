import { d as createAstro, c as createComponent, r as renderComponent, b as renderHead, f as renderSlot, e as addAttribute, a as renderTemplate } from './astro/server.BG-T_3SK.js';
import 'kleur/colors';
import { $ as $$BaseHead, a as $$Header, b as $$Footer } from './Footer.CQ1rSHsv.js';
import { $ as $$FormattedDate } from './FormattedDate.CT38LwCq.js';

const $$Astro = createAstro("https://codevs.kroko.cl");
const $$BlogPost = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$BlogPost;
  const { title, description, pubDate, updatedDate, heroImage } = Astro2.props;
  return renderTemplate`<html lang="en"> <head>${renderComponent($$result, "BaseHead", $$BaseHead, { "title": title, "description": description })}${renderHead()}</head> <body class="bg-white dark:bg-gray-900 text-gray-900 dark:text-white min-h-screen"> ${renderComponent($$result, "Header", $$Header, {})} <main class="w-full"> <article> ${heroImage && renderTemplate`<div class="w-full mb-8"> <img${addAttribute(1020, "width")}${addAttribute(510, "height")}${addAttribute(heroImage, "src")} alt="" class="block mx-auto rounded-xl shadow-2xl max-w-full h-auto"> </div>`} <div class="prose prose-lg dark:prose-invert max-w-3xl mx-auto px-4 py-8"> <div class="text-center mb-8 border-b border-gray-200 dark:border-gray-700 pb-8"> <div class="text-gray-600 dark:text-gray-400 mb-4"> ${renderComponent($$result, "FormattedDate", $$FormattedDate, { "date": pubDate })} ${updatedDate && renderTemplate`<div class="italic text-sm mt-2">
Last updated on ${renderComponent($$result, "FormattedDate", $$FormattedDate, { "date": updatedDate })} </div>`} </div> <h1 class="text-4xl font-bold mb-0 gradient-text"> ${title} </h1> </div> <div class="prose-headings:text-gray-900 dark:prose-headings:text-white prose-p:text-gray-700 dark:prose-p:text-gray-300 prose-a:text-accent-600 dark:prose-a:text-accent-400 prose-strong:text-gray-900 dark:prose-strong:text-white prose-code:text-accent-700 dark:prose-code:text-accent-300 prose-pre:bg-gray-100 dark:prose-pre:bg-gray-900 prose-blockquote:border-l-primary-500"> ${renderSlot($$result, $$slots["default"])} </div> </div> </article> </main> ${renderComponent($$result, "Footer", $$Footer, {})} </body></html>`;
}, "F:/Codes/CODEVS/ASTRO-WEB/codevs-blog/src/layouts/BlogPost.astro", void 0);

export { $$BlogPost as $ };
