const SITE_TITLE = "Codevs";
const SITE_DESCRIPTION = "¡Bienvenidos a Codevs!";

export { SITE_DESCRIPTION as S, SITE_TITLE as a };
